//file per gestire gli aggiornamenti di DB tra le pagine
export const databaseChannel =  new BroadcastChannel("aggiornamentoDatabase");